// firebaseConfig.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";

export const firebaseConfig = {
    
};

export const app = initializeApp(firebaseConfig);
